// ============================================================
// db.js - Camada de dados do BRMW
// Persistência em arquivo JSON (sem dependências externas),
// mas o SCHEMA abaixo espelha fielmente as tabelas definidas
// em criar_banco_brmw.sql (colunas, obrigatoriedade, chaves
// estrangeiras e a checagem de times diferentes em PARTIDAS).
// ============================================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_FILE = path.join(__dirname, 'data.json');

// Ordem de dependência (para import em lote / seed): tabelas-mãe primeiro.
const ENTITY_ORDER = [
  'usuarios',
  'clubes',
  'temporadas',
  'jogadores',
  'estatisticas',
  'partidas',
];

const SCHEMA = {
  usuarios: {
    pk: 'id_usuario',
    label: 'Usuários',
    fields: {
      nome: { type: 'string', required: true },
      email: { type: 'string', required: true, unique: true },
      senha_hash: { type: 'string', required: true },
      criado_em: { type: 'string', required: false, auto: () => new Date().toISOString() },
    },
  },
  clubes: {
    pk: 'id_clube',
    label: 'Clubes',
    fields: {
      nome: { type: 'string', required: true },
      cidade: { type: 'string', required: false },
      criado_em: { type: 'string', required: false, auto: () => new Date().toISOString() },
    },
  },
  temporadas: {
    pk: 'id_temporada',
    label: 'Temporadas',
    fields: {
      nome: { type: 'string', required: true },
      data_inicio: { type: 'string', required: false },
      data_fim: { type: 'string', required: false },
      status: { type: 'string', required: false },
    },
  },
  jogadores: {
    pk: 'id_jogador',
    label: 'Jogadores',
    fields: {
      id_usuario: { type: 'number', required: true, fk: 'usuarios' },
      nome: { type: 'string', required: true },
      data_nascimento: { type: 'string', required: false },
      posicao: { type: 'string', required: false },
      criado_em: { type: 'string', required: false, auto: () => new Date().toISOString() },
    },
  },
  estatisticas: {
    pk: 'id_estatistica',
    label: 'Estatísticas',
    fields: {
      id_jogador: { type: 'number', required: true, fk: 'jogadores' },
      jogos: { type: 'number', required: false, default: 0 },
      gols: { type: 'number', required: false, default: 0 },
      assistencias: { type: 'number', required: false, default: 0 },
      cartoes_amarelos: { type: 'number', required: false, default: 0 },
      cartoes_vermelhos: { type: 'number', required: false, default: 0 },
      atualizado_em: { type: 'string', required: false, auto: () => new Date().toISOString() },
    },
  },
  partidas: {
    pk: 'id_partida',
    label: 'Partidas',
    fields: {
      id_temporada: { type: 'number', required: true, fk: 'temporadas' },
      id_time_mandante: { type: 'number', required: true, fk: 'clubes' },
      id_time_visitante: { type: 'number', required: true, fk: 'clubes' },
      data_partida: { type: 'string', required: false },
      campeonato: { type: 'string', required: false },
      gols_mandante: { type: 'number', required: false, default: 0 },
      gols_visitante: { type: 'number', required: false, default: 0 },
      status: { type: 'string', required: false },
    },
    validate(record) {
      if (Number(record.id_time_mandante) === Number(record.id_time_visitante)) {
        throw new Error('id_time_mandante e id_time_visitante devem ser diferentes (chk_times_diferentes).');
      }
    },
  },
};

function emptyState() {
  const state = { _counters: {}, _sessions: {} };
  for (const entity of ENTITY_ORDER) {
    state[entity] = [];
    state._counters[entity] = 1;
  }
  return state;
}

function load() {
  if (!fs.existsSync(DB_FILE)) {
    const state = emptyState();
    save(state);
    return state;
  }
  try {
    const state = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    if (!state._sessions) state._sessions = {}; // compatibilidade com data.json antigo
    return state;
  } catch (err) {
    console.error('Falha ao ler data.json, recriando banco vazio.', err);
    const state = emptyState();
    save(state);
    return state;
  }
}

function save(state) {
  fs.writeFileSync(DB_FILE, JSON.stringify(state, null, 2), 'utf-8');
}

function assertEntity(entity) {
  if (!SCHEMA[entity]) {
    const err = new Error(`Cadastro desconhecido: ${entity}`);
    err.status = 404;
    throw err;
  }
}

function coerce(value, type) {
  if (value === undefined || value === null || value === '') return undefined;
  if (type === 'number') {
    const n = Number(value);
    if (Number.isNaN(n)) throw new Error(`Valor numérico inválido: "${value}"`);
    return n;
  }
  return String(value).trim();
}

// Valida e normaliza um registro de acordo com o schema da entidade,
// checando obrigatoriedade, tipos, unicidade e chaves estrangeiras.
function buildRecord(entity, input, state) {
  const def = SCHEMA[entity];
  const record = {};

  for (const [field, rules] of Object.entries(def.fields)) {
    let value = coerce(input[field], rules.type);

    if (value === undefined) {
      if (rules.required) {
        throw new Error(`Campo obrigatório ausente: ${field}`);
      }
      if (rules.auto) value = rules.auto();
      else if (rules.default !== undefined) value = rules.default;
    }

    if (value !== undefined && rules.fk) {
      const exists = state[rules.fk].some((r) => r[SCHEMA[rules.fk].pk] === value);
      if (!exists) {
        throw new Error(`Chave estrangeira inválida: ${field}=${value} não existe em ${rules.fk}.`);
      }
    }

    if (value !== undefined && rules.unique) {
      const clash = state[entity].some((r) => r[field] === value);
      if (clash) {
        throw new Error(`Valor duplicado para campo único "${field}": ${value}`);
      }
    }

    record[field] = value;
  }

  if (def.validate) def.validate(record);

  return record;
}

function listAll(entity) {
  assertEntity(entity);
  const state = load();
  return state[entity];
}

function insert(entity, input) {
  assertEntity(entity);
  const state = load();
  const def = SCHEMA[entity];
  const record = buildRecord(entity, input, state);
  const id = state._counters[entity]++;
  record[def.pk] = id;
  state[entity].push(record);
  save(state);
  return record;
}

function remove(entity, id) {
  assertEntity(entity);
  const state = load();
  const def = SCHEMA[entity];
  const idx = state[entity].findIndex((r) => r[def.pk] === Number(id));
  if (idx === -1) {
    const err = new Error('Registro não encontrado.');
    err.status = 404;
    throw err;
  }
  // Impede remoção se houver dependentes (equivalente a ON DELETE RESTRICT).
  for (const [otherEntity, otherDef] of Object.entries(SCHEMA)) {
    for (const [field, rules] of Object.entries(otherDef.fields)) {
      if (rules.fk === entity) {
        const dependent = state[otherEntity].some((r) => r[field] === Number(id));
        if (dependent) {
          throw new Error(
            `Não é possível remover: existem registros em "${otherEntity}" vinculados a este ${entity}.`
          );
        }
      }
    }
  }
  const [removed] = state[entity].splice(idx, 1);
  save(state);
  return removed;
}

// Importação em lote (usada pela importação de planilha Excel).
// Cada linha é validada individualmente; falhas não interrompem as demais.
function bulkInsert(entity, rows) {
  assertEntity(entity);
  const state = load();
  const def = SCHEMA[entity];
  const inserted = [];
  const errors = [];

  rows.forEach((row, i) => {
    try {
      const record = buildRecord(entity, row, state);
      const id = state._counters[entity]++;
      record[def.pk] = id;
      state[entity].push(record);
      inserted.push(record);
    } catch (err) {
      errors.push({ linha: i + 2, erro: err.message }); // +2 = cabeçalho + índice 1-based
    }
  });

  save(state);
  return { inserted, errors };
}

function stats() {
  const state = load();
  const out = {};
  for (const entity of ENTITY_ORDER) out[entity] = state[entity].length;
  return out;
}

// ------------------------------------------------------------
// Autenticação: senha nunca é guardada em texto puro.
// Formato armazenado em USUARIOS.senha_hash: "salt:hash" (scrypt).
// ------------------------------------------------------------

function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(plain), salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(plain, stored) {
  if (!stored || typeof stored !== 'string' || !stored.includes(':')) return false;
  const [salt, hash] = stored.split(':');
  const check = crypto.scryptSync(String(plain), salt, 64);
  const original = Buffer.from(hash, 'hex');
  if (original.length !== check.length) return false;
  return crypto.timingSafeEqual(original, check);
}

function sanitizeUsuario(usuario) {
  if (!usuario) return usuario;
  const { senha_hash, ...safe } = usuario;
  return safe;
}

function createSession(id_usuario) {
  const state = load();
  const token = crypto.randomBytes(32).toString('hex');
  state._sessions[token] = { id_usuario, criado_em: new Date().toISOString() };
  save(state);
  return token;
}

function getSessionUser(token) {
  if (!token) return null;
  const state = load();
  const session = state._sessions[token];
  if (!session) return null;
  const usuario = state.usuarios.find((u) => u.id_usuario === session.id_usuario);
  return sanitizeUsuario(usuario);
}

function deleteSession(token) {
  const state = load();
  delete state._sessions[token];
  save(state);
}

// Cadastro de conta nova: cria o registro em USUARIOS (com senha já
// hasheada) e devolve o usuário logado (com token de sessão).
function registerUser({ nome, email, senha }) {
  if (!senha || String(senha).length < 6) {
    throw new Error('A senha deve ter pelo menos 6 caracteres.');
  }
  const usuario = insert('usuarios', { nome, email, senha_hash: hashPassword(senha) });
  const token = createSession(usuario.id_usuario);
  return { token, usuario: sanitizeUsuario(usuario) };
}

// Login: confere e-mail + senha e abre uma nova sessão.
function loginUser({ email, senha }) {
  const state = load();
  const usuario = state.usuarios.find((u) => u.email === String(email || '').trim());
  if (!usuario || !verifyPassword(senha, usuario.senha_hash)) {
    throw new Error('E-mail ou senha inválidos.');
  }
  const token = createSession(usuario.id_usuario);
  return { token, usuario: sanitizeUsuario(usuario) };
}

module.exports = {
  SCHEMA,
  ENTITY_ORDER,
  listAll,
  insert,
  remove,
  bulkInsert,
  stats,
  hashPassword,
  sanitizeUsuario,
  registerUser,
  loginUser,
  getSessionUser,
  deleteSession,
};
