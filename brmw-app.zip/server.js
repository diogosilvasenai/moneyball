// ============================================================
// server.js - Backend BRMW
// Servidor HTTP puro (sem express nem outras dependências
// externas) expondo uma API REST para os cadastros definidos
// em db.js, e servindo o frontend estático.
// ============================================================

const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 10 * 1024 * 1024) {
        reject(new Error('Corpo da requisição excede o limite de 10MB.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(new Error('JSON inválido no corpo da requisição.'));
      }
    });
    req.on('error', reject);
  });
}

function getToken(req) {
  const header = req.headers['authorization'] || '';
  const [scheme, token] = header.split(' ');
  return scheme === 'Bearer' ? token : null;
}

// Remove senha_hash de qualquer registro/lista de USUARIOS antes de responder.
function stripSenha(entity, payload) {
  if (entity !== 'usuarios') return payload;
  if (Array.isArray(payload)) return payload.map(db.sanitizeUsuario);
  return db.sanitizeUsuario(payload);
}

function serveStatic(req, res) {
  let reqPath = decodeURIComponent(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';
  const filePath = path.normalize(path.join(FRONTEND_DIR, reqPath));

  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    return res.end('Acesso negado.');
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Não encontrado.');
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// Converte o campo "senha" (texto puro, vindo do formulário) em
// "senha_hash" antes de gravar. Usado no cadastro manual de USUARIOS
// e na importação por planilha, para nunca persistir senha em texto puro.
function withHashedPassword(entity, body) {
  if (entity !== 'usuarios' || !body || !body.senha) return body;
  const clone = { ...body };
  clone.senha_hash = db.hashPassword(clone.senha);
  delete clone.senha;
  return clone;
}

async function handleAuth(req, res, parts) {
  const action = parts[2]; // registro | login | logout | me

  try {
    if (req.method === 'POST' && action === 'registro') {
      const body = await readBody(req);
      const result = db.registerUser(body);
      return sendJson(res, 201, result);
    }

    if (req.method === 'POST' && action === 'login') {
      const body = await readBody(req);
      const result = db.loginUser(body);
      return sendJson(res, 200, result);
    }

    if (req.method === 'POST' && action === 'logout') {
      db.deleteSession(getToken(req));
      return sendJson(res, 200, { ok: true });
    }

    if (req.method === 'GET' && action === 'me') {
      const usuario = db.getSessionUser(getToken(req));
      if (!usuario) return sendJson(res, 401, { erro: 'Sessão inválida ou expirada.' });
      return sendJson(res, 200, { usuario });
    }

    return sendJson(res, 404, { erro: 'Rota de autenticação não encontrada.' });
  } catch (err) {
    return sendJson(res, err.status || 400, { erro: err.message });
  }
}

async function handleApi(req, res, parts) {
  // parts: ['api', entity, id?] ou ['api', entity, 'import']

  // Todas as rotas de cadastro exigem um login válido (Bearer token).
  const usuarioLogado = db.getSessionUser(getToken(req));
  if (!usuarioLogado) {
    return sendJson(res, 401, { erro: 'Não autenticado. Faça login para continuar.' });
  }

  const entity = parts[1];
  const sub = parts[2];

  try {
    if (req.method === 'GET' && parts.length === 2 && entity === 'stats') {
      return sendJson(res, 200, db.stats());
    }

    if (req.method === 'GET' && parts.length === 2) {
      return sendJson(res, 200, stripSenha(entity, db.listAll(entity)));
    }

    if (req.method === 'POST' && parts.length === 3 && sub === 'import') {
      const body = await readBody(req);
      const rows = (Array.isArray(body.rows) ? body.rows : []).map((row) => withHashedPassword(entity, row));
      const result = db.bulkInsert(entity, rows);
      result.inserted = stripSenha(entity, result.inserted);
      return sendJson(res, 200, result);
    }

    if (req.method === 'POST' && parts.length === 2) {
      const body = await readBody(req);
      const record = db.insert(entity, withHashedPassword(entity, body));
      return sendJson(res, 201, stripSenha(entity, record));
    }

    if (req.method === 'DELETE' && parts.length === 3) {
      const removed = db.remove(entity, sub);
      return sendJson(res, 200, stripSenha(entity, removed));
    }

    return sendJson(res, 404, { erro: 'Rota não encontrada.' });
  } catch (err) {
    return sendJson(res, err.status || 400, { erro: err.message });
  }
}

const server = http.createServer((req, res) => {
  const parts = req.url.split('?')[0].split('/').filter(Boolean);

  if (parts[0] === 'api' && parts[1] === 'auth') {
    handleAuth(req, res, parts);
  } else if (parts[0] === 'api') {
    handleApi(req, res, parts);
  } else {
    serveStatic(req, res);
  }
});

server.listen(PORT, () => {
  console.log(`BRMW rodando em http://localhost:${PORT}`);
});
