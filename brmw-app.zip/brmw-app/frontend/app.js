// ============================================================
// app.js - Frontend BRMW
// Vanilla JS. Renderiza abas de cadastro a partir de um
// pequeno "schema" declarativo e conversa com a API REST do
// backend. A importação de Excel usa SheetJS (via CDN) para
// ler o arquivo no navegador; nada é enviado como binário —
// os dados já chegam ao servidor como JSON.
// ============================================================

const API = '/api';

// Ordem = ordem de dependência das chaves estrangeiras.
const ENTITIES = [
  {
    key: 'usuarios',
    label: 'Usuários',
    desc: 'Contas que acessam o sistema. Cada jogador está vinculado a um usuário.',
    pk: 'id_usuario',
    fields: [
      { name: 'nome', label: 'Nome', type: 'text', required: true },
      { name: 'email', label: 'E-mail', type: 'email', required: true },
      { name: 'senha_hash', label: 'Senha (hash)', type: 'text', required: true, placeholder: 'hash já processado' },
    ],
    columns: [
      { key: 'id_usuario', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'email', label: 'E-mail' },
      { key: 'criado_em', label: 'Criado em', format: 'datetime' },
    ],
  },
  {
    key: 'clubes',
    label: 'Clubes',
    desc: 'Times que disputam partidas dentro das temporadas.',
    pk: 'id_clube',
    fields: [
      { name: 'nome', label: 'Nome do clube', type: 'text', required: true },
      { name: 'cidade', label: 'Cidade', type: 'text' },
    ],
    columns: [
      { key: 'id_clube', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'cidade', label: 'Cidade' },
      { key: 'criado_em', label: 'Criado em', format: 'datetime' },
    ],
  },
  {
    key: 'temporadas',
    label: 'Temporadas',
    desc: 'Períodos de competição que agrupam as partidas.',
    pk: 'id_temporada',
    fields: [
      { name: 'nome', label: 'Nome', type: 'text', required: true, placeholder: 'ex.: Temporada 2026' },
      { name: 'data_inicio', label: 'Início', type: 'date' },
      { name: 'data_fim', label: 'Fim', type: 'date' },
      { name: 'status', label: 'Status', type: 'select', options: ['Planejada', 'Em andamento', 'Encerrada'] },
    ],
    columns: [
      { key: 'id_temporada', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'data_inicio', label: 'Início' },
      { key: 'data_fim', label: 'Fim' },
      { key: 'status', label: 'Status' },
    ],
  },
  {
    key: 'jogadores',
    label: 'Jogadores',
    desc: 'Atletas vinculados a um usuário do sistema.',
    pk: 'id_jogador',
    fields: [
      { name: 'id_usuario', label: 'Usuário', type: 'fk', fk: 'usuarios', fkLabel: 'nome', required: true },
      { name: 'nome', label: 'Nome do jogador', type: 'text', required: true },
      { name: 'data_nascimento', label: 'Data de nascimento', type: 'date' },
      {
        name: 'posicao', label: 'Posição', type: 'select',
        options: ['Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Atacante'],
      },
    ],
    columns: [
      { key: 'id_jogador', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'posicao', label: 'Posição' },
      { key: 'data_nascimento', label: 'Nascimento' },
      { key: 'id_usuario', label: 'Usuário', format: 'fk', fk: 'usuarios', fkLabel: 'nome' },
    ],
  },
  {
    key: 'estatisticas',
    label: 'Estatísticas',
    desc: 'Números acumulados de cada jogador (uma linha por jogador/atualização).',
    pk: 'id_estatistica',
    fields: [
      { name: 'id_jogador', label: 'Jogador', type: 'fk', fk: 'jogadores', fkLabel: 'nome', required: true },
      { name: 'jogos', label: 'Jogos', type: 'number', min: 0, placeholder: '0' },
      { name: 'gols', label: 'Gols', type: 'number', min: 0, placeholder: '0' },
      { name: 'assistencias', label: 'Assistências', type: 'number', min: 0, placeholder: '0' },
      { name: 'cartoes_amarelos', label: 'Cartões amarelos', type: 'number', min: 0, placeholder: '0' },
      { name: 'cartoes_vermelhos', label: 'Cartões vermelhos', type: 'number', min: 0, placeholder: '0' },
    ],
    columns: [
      { key: 'id_jogador', label: 'Jogador', format: 'fk', fk: 'jogadores', fkLabel: 'nome' },
      { key: 'jogos', label: 'J', mono: true },
      { key: 'gols', label: 'G', mono: true },
      { key: 'assistencias', label: 'A', mono: true },
      { key: 'cartoes_amarelos', label: 'CA', mono: true },
      { key: 'cartoes_vermelhos', label: 'CV', mono: true },
      { key: 'atualizado_em', label: 'Atualizado em', format: 'datetime' },
    ],
  },
  {
    key: 'partidas',
    label: 'Partidas',
    desc: 'Confrontos entre dois clubes dentro de uma temporada.',
    pk: 'id_partida',
    fields: [
      { name: 'id_temporada', label: 'Temporada', type: 'fk', fk: 'temporadas', fkLabel: 'nome', required: true },
      { name: 'id_time_mandante', label: 'Mandante', type: 'fk', fk: 'clubes', fkLabel: 'nome', required: true },
      { name: 'id_time_visitante', label: 'Visitante', type: 'fk', fk: 'clubes', fkLabel: 'nome', required: true },
      { name: 'data_partida', label: 'Data/hora', type: 'datetime-local' },
      { name: 'campeonato', label: 'Campeonato', type: 'text' },
      { name: 'gols_mandante', label: 'Gols mandante', type: 'number', min: 0, placeholder: '0' },
      { name: 'gols_visitante', label: 'Gols visitante', type: 'number', min: 0, placeholder: '0' },
      { name: 'status', label: 'Status', type: 'select', options: ['Agendada', 'Em andamento', 'Encerrada', 'Adiada'] },
    ],
    columns: [
      { key: 'id_time_mandante', label: 'Mandante', format: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { key: 'placar', label: 'Placar', custom: (row) => `${row.gols_mandante ?? 0} x ${row.gols_visitante ?? 0}` },
      { key: 'id_time_visitante', label: 'Visitante', format: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { key: 'id_temporada', label: 'Temporada', format: 'fk', fk: 'temporadas', fkLabel: 'nome' },
      { key: 'campeonato', label: 'Campeonato' },
      { key: 'status', label: 'Status' },
    ],
  },
];

const cache = {};      // entity -> array of records
let activeKey = ENTITIES[0].key;

const $app = document.getElementById('app');
const $tabs = document.getElementById('tabs');
const $strip = document.getElementById('scoreboard-strip');
const $report = document.getElementById('import-report');

function entityByKey(key) {
  return ENTITIES.find((e) => e.key === key);
}

async function api(path, options) {
  const res = await fetch(API + path, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.erro || 'Erro desconhecido.');
  return data;
}

async function refreshEntity(key) {
  cache[key] = await api(`/${key}`);
}

async function refreshAll() {
  await Promise.all(ENTITIES.map((e) => refreshEntity(e.key)));
  renderScoreboard();
}

// ------------------------------------------------------------
// Scoreboard (contador ao vivo por cadastro)
// ------------------------------------------------------------
function renderScoreboard() {
  $strip.innerHTML = ENTITIES.map((e) => `
    <div class="score-cell">
      <span class="score-digits">${String(cache[e.key]?.length ?? 0).padStart(2, '0')}</span>
      <span class="score-label">${e.label}</span>
    </div>
  `).join('<span class="score-div"></span>');
}

// ------------------------------------------------------------
// Abas
// ------------------------------------------------------------
function renderTabs() {
  $tabs.innerHTML = ENTITIES.map((e) => `
    <button class="tab ${e.key === activeKey ? 'active' : ''}" data-key="${e.key}">${e.label}</button>
  `).join('');
  $tabs.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      activeKey = btn.dataset.key;
      renderTabs();
      renderSection(activeKey);
    });
  });
}

// ------------------------------------------------------------
// Formatação de células
// ------------------------------------------------------------
function fkLabelFor(fk, fkLabelField, id) {
  const list = cache[fk] || [];
  const row = list.find((r) => r[entityByKey(fk).pk] === Number(id));
  return row ? `${row[fkLabelField]} (#${id})` : `#${id}`;
}

function formatCell(col, row) {
  if (col.custom) return col.custom(row);
  const value = row[col.key];
  if (value === undefined || value === null || value === '') return '—';
  if (col.format === 'fk') return fkLabelFor(col.fk, col.fkLabel, value);
  if (col.format === 'datetime') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleString('pt-BR');
  }
  return value;
}

// ------------------------------------------------------------
// Formulário
// ------------------------------------------------------------
function buildFieldControl(field) {
  const wrap = document.createElement('label');
  wrap.className = 'field';
  wrap.innerHTML = `<span>${field.label}${field.required ? ' *' : ''}</span>`;

  let control;
  if (field.type === 'select') {
    control = document.createElement('select');
    control.innerHTML = `<option value="">Selecione…</option>` +
      field.options.map((o) => `<option value="${o}">${o}</option>`).join('');
  } else if (field.type === 'fk') {
    control = document.createElement('select');
    const list = cache[field.fk] || [];
    control.innerHTML = `<option value="">Selecione…</option>` +
      list.map((r) => `<option value="${r[entityByKey(field.fk).pk]}">${r[field.fkLabel]} (#${r[entityByKey(field.fk).pk]})</option>`).join('');
  } else {
    control = document.createElement('input');
    control.type = field.type;
    if (field.placeholder) control.placeholder = field.placeholder;
    if (field.min !== undefined) control.min = field.min;
  }
  control.name = field.name;
  if (field.required) control.required = true;
  wrap.appendChild(control);
  return wrap;
}

function renderSection(key) {
  const entity = entityByKey(key);
  const tpl = document.getElementById('tpl-section');
  const node = tpl.content.cloneNode(true);

  node.querySelector('h2').textContent = entity.label;
  node.querySelector('.panel-desc').textContent = entity.desc;

  const form = node.querySelector('.record-form');
  entity.fields.forEach((f) => form.appendChild(buildFieldControl(f)));
  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn btn-gold field-submit';
  submit.textContent = `Cadastrar ${entity.label.toLowerCase()}`;
  form.appendChild(submit);

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const payload = {};
    entity.fields.forEach((f) => { payload[f.name] = form.elements[f.name].value; });
    try {
      await api(`/${key}`, { method: 'POST', body: JSON.stringify(payload) });
      form.reset();
      await refreshAll();
      renderSection(key);
    } catch (err) {
      alert(err.message);
    }
  });

  const thead = node.querySelector('thead');
  thead.innerHTML = '<tr>' + entity.columns.map((c) => `<th>${c.label}</th>`).join('') + '<th></th></tr>';

  const tbody = node.querySelector('tbody');
  const rows = cache[key] || [];
  const emptyState = node.querySelector('.empty-state');
  emptyState.classList.toggle('hidden', rows.length > 0);

  rows.slice().reverse().forEach((row) => {
    const tr = document.createElement('tr');
    tr.innerHTML = entity.columns.map((c) => `<td class="${c.mono ? 'mono' : ''}">${formatCell(c, row)}</td>`).join('');
    const tdActions = document.createElement('td');
    tdActions.className = 'row-actions';
    const del = document.createElement('button');
    del.className = 'btn-icon';
    del.title = 'Remover';
    del.textContent = '✕';
    del.addEventListener('click', async () => {
      if (!confirm('Remover este registro?')) return;
      try {
        await api(`/${key}/${row[entity.pk]}`, { method: 'DELETE' });
        await refreshAll();
        renderSection(key);
      } catch (err) {
        alert(err.message);
      }
    });
    tdActions.appendChild(del);
    tr.appendChild(tdActions);
    tbody.appendChild(tr);
  });

  $app.innerHTML = '';
  $app.appendChild(node);
}

// ------------------------------------------------------------
// Excel: baixar modelo
// ------------------------------------------------------------
document.getElementById('btn-template').addEventListener('click', () => {
  const wb = XLSX.utils.book_new();
  ENTITIES.forEach((entity) => {
    const headers = entity.fields.map((f) => f.name);
    const example = entity.fields.map((f) => (f.type === 'fk' ? 1 : f.placeholder || ''));
    const ws = XLSX.utils.aoa_to_sheet([headers, example]);
    XLSX.utils.book_append_sheet(wb, ws, entity.key.toUpperCase());
  });
  XLSX.writeFile(wb, 'modelo_brmw.xlsx');
});

// ------------------------------------------------------------
// Excel: importar planilha
// ------------------------------------------------------------
document.getElementById('file-import').addEventListener('change', async (ev) => {
  const file = ev.target.files[0];
  if (!file) return;

  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  const summary = [];

  for (const entity of ENTITIES) {
    const sheetName = workbook.SheetNames.find(
      (name) => name.trim().toLowerCase() === entity.key.toLowerCase()
    );
    if (!sheetName) continue;

    const sheet = workbook.Sheets[sheetName];
    const rawRows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    const rows = rawRows
      .map((r) => {
        const normalized = {};
        Object.entries(r).forEach(([k, v]) => { normalized[k.trim().toLowerCase()] = v; });
        return normalized;
      })
      .filter((r) => Object.values(r).some((v) => String(v).trim() !== ''));

    if (rows.length === 0) continue;

    try {
      const result = await api(`/${entity.key}/import`, {
        method: 'POST',
        body: JSON.stringify({ rows }),
      });
      summary.push({ entity, ...result });
      await refreshEntity(entity.key); // dados novos ficam disponíveis para as próximas abas (FKs)
    } catch (err) {
      summary.push({ entity, inserted: [], errors: [{ linha: '-', erro: err.message }] });
    }
  }

  await refreshAll();
  renderSection(activeKey);
  renderImportReport(summary);
  ev.target.value = '';
});

function renderImportReport(summary) {
  if (summary.length === 0) {
    $report.classList.remove('hidden');
    $report.innerHTML = `<p>Nenhuma aba da planilha correspondeu a um cadastro conhecido (USUARIOS, CLUBES, TEMPORADAS, JOGADORES, ESTATISTICAS, PARTIDAS).</p>`;
    return;
  }
  $report.classList.remove('hidden');
  $report.innerHTML = `
    <div class="import-report-head">
      <strong>Importação concluída</strong>
      <button id="close-report" class="btn-icon">✕</button>
    </div>
    ${summary.map((s) => `
      <div class="import-line">
        <span class="import-entity">${s.entity.label}</span>
        <span class="import-ok">${s.inserted.length} importado(s)</span>
        ${s.errors.length ? `<span class="import-err">${s.errors.length} erro(s)</span>` : ''}
        ${s.errors.length ? `<ul class="import-errlist">${s.errors.map((e) => `<li>Linha ${e.linha}: ${e.erro}</li>`).join('')}</ul>` : ''}
      </div>
    `).join('')}
  `;
  document.getElementById('close-report').addEventListener('click', () => $report.classList.add('hidden'));
}

// ------------------------------------------------------------
// Boot
// ------------------------------------------------------------
(async function init() {
  await refreshAll();
  renderTabs();
  renderSection(activeKey);
})();
