// ============================================================
// server.js - Backend BRMW
// Servidor HTTP puro (sem express nem outras dependências
// externas) expondo uma API REST para os cadastros definidos
// em db.js, e servindo o frontend estático.
// ============================================================

const http = require('http');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const FRONTEND_DIR = path.join(__dirname, '..', 'frontend');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (chunk) => {
      data += chunk;
      if (data.length > 10 * 1024 * 1024) {
        reject(new Error('Corpo da requisição excede o limite de 10MB.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(new Error('JSON inválido no corpo da requisição.'));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res) {
  let reqPath = decodeURIComponent(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';
  const filePath = path.normalize(path.join(FRONTEND_DIR, reqPath));

  if (!filePath.startsWith(FRONTEND_DIR)) {
    res.writeHead(403);
    return res.end('Acesso negado.');
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('Não encontrado.');
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

async function handleApi(req, res, parts) {
  // parts: ['api', entity, id?] ou ['api', entity, 'import']
  const entity = parts[1];
  const sub = parts[2];

  try {
    if (req.method === 'GET' && parts.length === 2 && entity === 'stats') {
      return sendJson(res, 200, db.stats());
    }

    if (req.method === 'GET' && parts.length === 2) {
      return sendJson(res, 200, db.listAll(entity));
    }

    if (req.method === 'POST' && parts.length === 3 && sub === 'import') {
      const body = await readBody(req);
      const rows = Array.isArray(body.rows) ? body.rows : [];
      const result = db.bulkInsert(entity, rows);
      return sendJson(res, 200, result);
    }

    if (req.method === 'POST' && parts.length === 2) {
      const body = await readBody(req);
      const record = db.insert(entity, body);
      return sendJson(res, 201, record);
    }

    if (req.method === 'DELETE' && parts.length === 3) {
      const removed = db.remove(entity, sub);
      return sendJson(res, 200, removed);
    }

    return sendJson(res, 404, { erro: 'Rota não encontrada.' });
  } catch (err) {
    return sendJson(res, err.status || 400, { erro: err.message });
  }
}

const server = http.createServer((req, res) => {
  const parts = req.url.split('?')[0].split('/').filter(Boolean);

  if (parts[0] === 'api') {
    handleApi(req, res, parts);
  } else {
    serveStatic(req, res);
  }
});

server.listen(PORT, () => {
  console.log(`BRMW rodando em http://localhost:${PORT}`);
});
