# BRMW — Painel de Cadastros

Aplicação full-stack em JavaScript (sem dependências externas) para cadastrar
os dados do banco `brmw`, baseada no script `criar_banco_brmw.sql`.

## Estrutura

```
brmw-app/
├── backend/
│   ├── server.js   → servidor HTTP (API REST + arquivos estáticos)
│   ├── db.js        → schema, validações e persistência (data.json)
│   └── data.json     → criado automaticamente no primeiro cadastro
└── frontend/
    ├── index.html
    ├── style.css
    └── app.js        → também lê planilhas Excel com SheetJS (via CDN)
```

Não há `package.json`/dependências para instalar: o backend usa apenas os
módulos nativos do Node (`http`, `fs`, `path`) e o frontend é HTML/CSS/JS puro.
Os dados ficam persistidos em `backend/data.json`, com uma estrutura
equivalente às tabelas do script SQL (colunas, obrigatoriedade, chaves
estrangeiras e a checagem `chk_times_diferentes` de `PARTIDAS`).

> Observação: como não há um servidor MySQL neste ambiente, os dados são
> guardados em JSON no próprio backend, mas seguindo exatamente as mesmas
> tabelas/colunas/relacionamentos do `criar_banco_brmw.sql`. Se depois você
> quiser plugar um MySQL de verdade, basta trocar as funções de `db.js`
> por chamadas `mysql2` mantendo a mesma assinatura (`listAll`, `insert`,
> `bulkInsert`, `remove`).

## Como rodar

```bash
cd brmw-app/backend
node server.js
```

Acesse **http://localhost:3000**.

## Cadastros (abas)

Os seis cadastros seguem exatamente as tabelas do banco, agrupados um a um
por aba: **Usuários, Clubes, Temporadas, Jogadores, Estatísticas, Partidas**.
Cada aba tem um formulário (com validação e menus para as chaves
estrangeiras) e a lista dos registros já cadastrados, com opção de remover
(a remoção é bloqueada se existirem registros dependentes, assim como o
`ON DELETE RESTRICT` do script original).

## Importar planilha Excel

O botão **"Importar planilha Excel"** lê o arquivo inteiramente no navegador
(usando a biblioteca SheetJS) e envia os dados já convertidos para JSON ao
backend — nada de binário trafega pela rede.

A planilha deve ter uma aba para cada tabela que você quiser importar, com o
**nome da aba igual ao nome da tabela** (não sensível a maiúsculas):
`USUARIOS`, `CLUBES`, `TEMPORADAS`, `JOGADORES`, `ESTATISTICAS`, `PARTIDAS`.
Os cabeçalhos das colunas devem ter o mesmo nome dos campos (ex.: `nome`,
`email`, `senha_hash`, `id_usuario`, `id_jogador`, `id_time_mandante`, etc.).

Use o botão **"Baixar modelo Excel"** para gerar um `.xlsx` já com as abas e
cabeçalhos corretos.

A importação processa as abas na ordem de dependência (Usuários → Clubes →
Temporadas → Jogadores → Estatísticas → Partidas), então você pode importar
tudo de uma vez em um único arquivo. Linhas com erro (campo obrigatório
faltando, e-mail duplicado, chave estrangeira inexistente, etc.) são
reportadas individualmente sem travar a importação das demais.
