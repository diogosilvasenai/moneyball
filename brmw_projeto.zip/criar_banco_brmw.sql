-- ============================================================
-- Script de criação do banco de dados - BRMW
-- Baseado no Modelo Lógico original, adaptado para a versão
-- PHP + MySQL da aplicação.
--
-- Compatível com MySQL 5.7+ / MariaDB, via phpMyAdmin.
-- (a checagem CHECK de "times diferentes" só é de fato aplicada
--  pelo próprio MySQL a partir da versão 8.0.16 / MariaDB 10.2+;
--  a aplicação PHP também valida essa regra, então funciona em
--  qualquer versão.)
--
-- Alterações em relação ao script original:
--   * Nova tabela SESSOES, usada para guardar o token de login
--     (Bearer token) de cada usuário autenticado.
--   * Nova coluna JOGADORES.id_clube (opcional): clube atual do
--     jogador. Necessária para o filtro "por clube" do
--     Dashboard/Ranking, que o modelo original não permitia.
--   * Nova coluna ESTATISTICAS.id_temporada (opcional): temporada
--     à qual aquela estatística se refere. Necessária para o
--     filtro "por temporada" do Dashboard/Ranking.
--   Nenhuma tabela/relacionamento existente foi removido.
-- ============================================================

DROP DATABASE IF EXISTS brmw;
CREATE DATABASE brmw
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE brmw;

-- ------------------------------------------------------------
-- Tabela: USUARIOS
-- ------------------------------------------------------------
CREATE TABLE USUARIOS (
    id_usuario   INT AUTO_INCREMENT PRIMARY KEY,
    nome         VARCHAR(100) NOT NULL,
    email        VARCHAR(150) NOT NULL UNIQUE,
    senha_hash   VARCHAR(255) NOT NULL,
    criado_em    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: SESSOES
-- Guarda o token de autenticação (Bearer) de cada login ativo.
-- ------------------------------------------------------------
CREATE TABLE SESSOES (
    token        VARCHAR(64) PRIMARY KEY,
    id_usuario   INT NOT NULL,
    criado_em    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sessoes_usuario
        FOREIGN KEY (id_usuario) REFERENCES USUARIOS(id_usuario)
        ON UPDATE CASCADE
        ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: CLUBES
-- ------------------------------------------------------------
CREATE TABLE CLUBES (
    id_clube     INT AUTO_INCREMENT PRIMARY KEY,
    nome         VARCHAR(120) NOT NULL,
    cidade       VARCHAR(100),
    criado_em    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: TEMPORADAS
-- ------------------------------------------------------------
CREATE TABLE TEMPORADAS (
    id_temporada INT AUTO_INCREMENT PRIMARY KEY,
    nome         VARCHAR(100) NOT NULL,
    data_inicio  DATE,
    data_fim     DATE,
    status       VARCHAR(30)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: JOGADORES
-- Relacionamento 1:N (USUARIOS -> JOGADORES) via id_usuario
-- Relacionamento N:1 (JOGADORES -> CLUBES) via id_clube (opcional)
-- ------------------------------------------------------------
CREATE TABLE JOGADORES (
    id_jogador       INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario       INT NOT NULL,
    id_clube         INT NULL,
    nome             VARCHAR(120) NOT NULL,
    data_nascimento  DATE,
    posicao          VARCHAR(50),
    criado_em        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_jogadores_usuario
        FOREIGN KEY (id_usuario) REFERENCES USUARIOS(id_usuario)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_jogadores_clube
        FOREIGN KEY (id_clube) REFERENCES CLUBES(id_clube)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: ESTATISTICAS
-- Relacionamento 1:N (JOGADORES -> ESTATISTICAS) via id_jogador
-- Relacionamento N:1 (ESTATISTICAS -> TEMPORADAS) via id_temporada (opcional)
-- ------------------------------------------------------------
CREATE TABLE ESTATISTICAS (
    id_estatistica     INT AUTO_INCREMENT PRIMARY KEY,
    id_jogador         INT NOT NULL,
    id_temporada       INT NULL,
    jogos              INT DEFAULT 0,
    gols               INT DEFAULT 0,
    assistencias       INT DEFAULT 0,
    cartoes_amarelos   INT DEFAULT 0,
    cartoes_vermelhos  INT DEFAULT 0,
    atualizado_em      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_estatisticas_jogador
        FOREIGN KEY (id_jogador) REFERENCES JOGADORES(id_jogador)
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT fk_estatisticas_temporada
        FOREIGN KEY (id_temporada) REFERENCES TEMPORADAS(id_temporada)
        ON UPDATE CASCADE
        ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: PARTIDAS
-- Relacionamento 1:N (TEMPORADAS -> PARTIDAS) via id_temporada
-- Relacionamento N:1 (PARTIDAS -> CLUBES) via id_time_mandante e id_time_visitante
-- ------------------------------------------------------------
CREATE TABLE PARTIDAS (
    id_partida         INT AUTO_INCREMENT PRIMARY KEY,
    id_temporada       INT NOT NULL,
    id_time_mandante   INT NOT NULL,
    id_time_visitante  INT NOT NULL,
    data_partida       TIMESTAMP NULL,
    campeonato         VARCHAR(120),
    gols_mandante      INT DEFAULT 0,
    gols_visitante     INT DEFAULT 0,
    status             VARCHAR(30),
    CONSTRAINT fk_partidas_temporada
        FOREIGN KEY (id_temporada) REFERENCES TEMPORADAS(id_temporada)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_partidas_time_mandante
        FOREIGN KEY (id_time_mandante) REFERENCES CLUBES(id_clube)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT fk_partidas_time_visitante
        FOREIGN KEY (id_time_visitante) REFERENCES CLUBES(id_clube)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,
    CONSTRAINT chk_times_diferentes
        CHECK (id_time_mandante <> id_time_visitante)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Índices auxiliares para as consultas de Dashboard/Ranking
-- ------------------------------------------------------------
CREATE INDEX idx_jogadores_clube ON JOGADORES (id_clube);
CREATE INDEX idx_estatisticas_jogador ON ESTATISTICAS (id_jogador);
CREATE INDEX idx_estatisticas_temporada ON ESTATISTICAS (id_temporada);
CREATE INDEX idx_partidas_temporada ON PARTIDAS (id_temporada);
CREATE INDEX idx_sessoes_usuario ON SESSOES (id_usuario);

-- ============================================================
-- Fim do script
-- ============================================================
