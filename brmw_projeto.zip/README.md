# BRMW — Painel de Cadastros (PHP + MySQL)

Aplicação full-stack para cadastrar os dados da liga (usuários, clubes,
temporadas, jogadores, estatísticas e partidas), agora com **backend em
PHP puro (PDO)** e **banco MySQL/MariaDB**, no lugar da versão anterior em
Node.js + `data.json`.

## Estrutura

```
brmw-app/
├── criar_banco_brmw.sql   → script para importar no phpMyAdmin
├── api/
│   ├── config.php          → dados de conexão com o MySQL (edite aqui)
│   ├── helpers.php         → funções comuns (JSON, autenticação)
│   ├── schema.php          → definição das tabelas/campos (mapa único)
│   ├── validate.php        → validação de obrigatoriedade/FK/unicidade
│   ├── auth.php            → cadastro de conta, login, logout, sessão
│   ├── crud.php            → listar, criar, editar, excluir (genérico)
│   ├── import.php          → importação em lote (planilha Excel)
│   ├── dashboard.php       → indicadores agregados
│   └── ranking.php         → ranking de jogadores com filtros
├── index.html
├── style.css
└── app.js                  → também lê planilhas Excel com SheetJS (via CDN)
```

## Como instalar

1. **Banco de dados**
   - Abra o phpMyAdmin e importe o arquivo `criar_banco_brmw.sql`
     (ele cria o banco `brmw` do zero, incluindo a tabela `SESSOES`
     usada para o login).
   - Isso cria as tabelas `USUARIOS`, `SESSOES`, `CLUBES`, `TEMPORADAS`,
     `JOGADORES`, `ESTATISTICAS` e `PARTIDAS`, com os relacionamentos
     entre elas.

2. **Backend**
   - Coloque a pasta do projeto (`brmw-app/`) dentro do seu servidor
     PHP (ex.: `htdocs` do XAMPP/WAMP, ou a raiz do seu domínio).
   - Edite `api/config.php` com o host, usuário, senha e nome do banco
     (por padrão: `localhost` / `root` / senha em branco / `brmw`).
   - Não é necessário instalar nada via Composer/NPM: o backend usa
     apenas PDO/MySQL nativo do PHP (>= 7.4).

3. **Acessar**
   - Abra `http://localhost/brmw-app/` (ajuste o caminho conforme onde
     você colocou a pasta) no navegador.

## Cadastro e login

1. Na tela inicial, clique em **"Criar conta"**, preencha nome, e-mail
   e senha (mínimo 6 caracteres) e envie.
2. A conta é gravada na tabela `USUARIOS` do MySQL (senha protegida com
   `password_hash()` do PHP — nunca texto puro).
3. Você já entra automaticamente após o cadastro (um token de sessão é
   criado em `SESSOES`).
4. Para logins seguintes, use **"Entrar"** com o mesmo e-mail e senha.
   O backend confere os dados em `USUARIOS` via `password_verify()`;
   se estiverem corretos, você acessa o painel — se não, uma mensagem
   de erro é exibida.

## Cadastros (abas)

Os seis cadastros seguem as tabelas do banco: **Usuários, Clubes,
Temporadas, Jogadores, Estatísticas, Partidas**. Cada aba tem:

- formulário de cadastro (com validação e menus para as chaves
  estrangeiras);
- lista dos registros já cadastrados, com **editar** (✎) e **remover**
  (✕). A remoção é bloqueada pelo próprio MySQL quando existem
  registros dependentes (equivalente ao `ON DELETE RESTRICT` do
  script SQL).

> Duas colunas opcionais foram adicionadas ao modelo original para
> viabilizar os filtros do Dashboard/Ranking pedidos: `JOGADORES.id_clube`
> (clube atual do jogador) e `ESTATISTICAS.id_temporada` (temporada da
> estatística). Nenhuma tabela ou relacionamento existente foi removido.

## Dashboard

Mostra indicadores calculados a partir dos dados reais do banco: total
de jogadores, clubes, partidas, gols, assistências e cartões,
artilheiros e garçons (top 5), partidas por temporada e médias gerais
por jogador.

## Ranking

Lista os jogadores a partir da tabela `ESTATISTICAS`, ordenáveis por
gols, assistências, jogos, cartões amarelos ou cartões vermelhos, com
filtros por temporada, clube e posição.

## Importar planilha Excel

O botão **"Baixar modelo Excel"** gera um `.xlsx` com uma aba por
tabela (`USUARIOS`, `CLUBES`, `TEMPORADAS`, `JOGADORES`,
`ESTATISTICAS`, `PARTIDAS`), cabeçalhos com o nome exato dos campos,
uma linha de exemplo preenchida e uma aba **"Instruções"** explicando
o que preencher em cada coluna. Campos gerados automaticamente pelo
banco (ids, datas de criação/atualização) não aparecem no modelo.

O botão **"Importar planilha Excel"** lê o arquivo inteiramente no
navegador (via SheetJS) e envia os dados já convertidos em JSON para
o backend PHP — nada de binário trafega pela rede. A importação
respeita a ordem de dependência (Usuários → Clubes → Temporadas →
Jogadores → Estatísticas → Partidas), então você pode importar tudo de
uma vez em um único arquivo. Linhas com erro (campo obrigatório
faltando, e-mail duplicado, chave estrangeira inexistente etc.) são
reportadas individualmente, sem travar a importação das demais.
