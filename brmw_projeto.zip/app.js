// ============================================================
// app.js - Frontend BRMW
// Vanilla JS. Conversa com o backend PHP (pasta api/) via fetch.
// A importação/exportação de Excel usa SheetJS (via CDN) para
// ler/gerar o arquivo no navegador; nada trafega como binário —
// os dados chegam ao servidor já como JSON.
// ============================================================

const API = 'api';
const TOKEN_KEY = 'brmw_token';

let currentUser = null;
let editingRecord = null; // { key, id } enquanto um formulário está em modo de edição

// Ordem = ordem de dependência das chaves estrangeiras.
const ENTITIES = [
  {
    key: 'usuarios',
    label: 'Usuários',
    desc: 'Contas que acessam o sistema. Cada jogador está vinculado a um usuário.',
    pk: 'id_usuario',
    fields: [
      { name: 'nome', label: 'Nome', type: 'text', required: true },
      { name: 'email', label: 'E-mail', type: 'email', required: true },
      { name: 'senha', label: 'Senha', type: 'password', required: true, placeholder: 'mín. 6 caracteres', editHint: 'deixe em branco para manter a senha atual' },
    ],
    columns: [
      { key: 'id_usuario', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'email', label: 'E-mail' },
      { key: 'criado_em', label: 'Criado em', format: 'datetime' },
    ],
  },
  {
    key: 'clubes',
    label: 'Clubes',
    desc: 'Times que disputam partidas dentro das temporadas.',
    pk: 'id_clube',
    fields: [
      { name: 'nome', label: 'Nome do clube', type: 'text', required: true },
      { name: 'cidade', label: 'Cidade', type: 'text' },
    ],
    columns: [
      { key: 'id_clube', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'cidade', label: 'Cidade' },
      { key: 'criado_em', label: 'Criado em', format: 'datetime' },
    ],
  },
  {
    key: 'temporadas',
    label: 'Temporadas',
    desc: 'Períodos de competição que agrupam as partidas.',
    pk: 'id_temporada',
    fields: [
      { name: 'nome', label: 'Nome', type: 'text', required: true, placeholder: 'ex.: Temporada 2026' },
      { name: 'data_inicio', label: 'Início', type: 'date' },
      { name: 'data_fim', label: 'Fim', type: 'date' },
      { name: 'status', label: 'Status', type: 'select', options: ['Planejada', 'Em andamento', 'Encerrada'] },
    ],
    columns: [
      { key: 'id_temporada', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'data_inicio', label: 'Início' },
      { key: 'data_fim', label: 'Fim' },
      { key: 'status', label: 'Status' },
    ],
  },
  {
    key: 'jogadores',
    label: 'Jogadores',
    desc: 'Atletas vinculados a um usuário do sistema e, opcionalmente, a um clube atual.',
    pk: 'id_jogador',
    fields: [
      { name: 'id_usuario', label: 'Usuário', type: 'fk', fk: 'usuarios', fkLabel: 'nome', required: true },
      { name: 'id_clube', label: 'Clube atual', type: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { name: 'nome', label: 'Nome do jogador', type: 'text', required: true },
      { name: 'data_nascimento', label: 'Data de nascimento', type: 'date' },
      {
        name: 'posicao', label: 'Posição', type: 'select',
        options: ['Goleiro', 'Zagueiro', 'Lateral', 'Volante', 'Meia', 'Atacante'],
      },
    ],
    columns: [
      { key: 'id_jogador', label: '#' },
      { key: 'nome', label: 'Nome' },
      { key: 'posicao', label: 'Posição' },
      { key: 'data_nascimento', label: 'Nascimento' },
      { key: 'id_clube', label: 'Clube', format: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { key: 'id_usuario', label: 'Usuário', format: 'fk', fk: 'usuarios', fkLabel: 'nome' },
    ],
  },
  {
    key: 'estatisticas',
    label: 'Estatísticas',
    desc: 'Números acumulados de cada jogador, opcionalmente ligados a uma temporada.',
    pk: 'id_estatistica',
    fields: [
      { name: 'id_jogador', label: 'Jogador', type: 'fk', fk: 'jogadores', fkLabel: 'nome', required: true },
      { name: 'id_temporada', label: 'Temporada', type: 'fk', fk: 'temporadas', fkLabel: 'nome' },
      { name: 'jogos', label: 'Jogos', type: 'number', min: 0, placeholder: '0' },
      { name: 'gols', label: 'Gols', type: 'number', min: 0, placeholder: '0' },
      { name: 'assistencias', label: 'Assistências', type: 'number', min: 0, placeholder: '0' },
      { name: 'cartoes_amarelos', label: 'Cartões amarelos', type: 'number', min: 0, placeholder: '0' },
      { name: 'cartoes_vermelhos', label: 'Cartões vermelhos', type: 'number', min: 0, placeholder: '0' },
    ],
    columns: [
      { key: 'id_jogador', label: 'Jogador', format: 'fk', fk: 'jogadores', fkLabel: 'nome' },
      { key: 'id_temporada', label: 'Temporada', format: 'fk', fk: 'temporadas', fkLabel: 'nome' },
      { key: 'jogos', label: 'J', mono: true },
      { key: 'gols', label: 'G', mono: true },
      { key: 'assistencias', label: 'A', mono: true },
      { key: 'cartoes_amarelos', label: 'CA', mono: true },
      { key: 'cartoes_vermelhos', label: 'CV', mono: true },
      { key: 'atualizado_em', label: 'Atualizado em', format: 'datetime' },
    ],
  },
  {
    key: 'partidas',
    label: 'Partidas',
    desc: 'Confrontos entre dois clubes dentro de uma temporada.',
    pk: 'id_partida',
    fields: [
      { name: 'id_temporada', label: 'Temporada', type: 'fk', fk: 'temporadas', fkLabel: 'nome', required: true },
      { name: 'id_time_mandante', label: 'Mandante', type: 'fk', fk: 'clubes', fkLabel: 'nome', required: true },
      { name: 'id_time_visitante', label: 'Visitante', type: 'fk', fk: 'clubes', fkLabel: 'nome', required: true },
      { name: 'data_partida', label: 'Data/hora', type: 'datetime-local' },
      { name: 'campeonato', label: 'Campeonato', type: 'text' },
      { name: 'gols_mandante', label: 'Gols mandante', type: 'number', min: 0, placeholder: '0' },
      { name: 'gols_visitante', label: 'Gols visitante', type: 'number', min: 0, placeholder: '0' },
      { name: 'status', label: 'Status', type: 'select', options: ['Agendada', 'Em andamento', 'Encerrada', 'Adiada'] },
    ],
    columns: [
      { key: 'id_time_mandante', label: 'Mandante', format: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { key: 'placar', label: 'Placar', custom: (row) => `${row.gols_mandante ?? 0} x ${row.gols_visitante ?? 0}` },
      { key: 'id_time_visitante', label: 'Visitante', format: 'fk', fk: 'clubes', fkLabel: 'nome' },
      { key: 'id_temporada', label: 'Temporada', format: 'fk', fk: 'temporadas', fkLabel: 'nome' },
      { key: 'campeonato', label: 'Campeonato' },
      { key: 'status', label: 'Status' },
    ],
  },
];

// Abas extras, sem cadastro próprio (usam endpoints agregados).
const VIEWS_EXTRA = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'ranking', label: 'Ranking' },
];

const cache = {};      // entity -> array of records
let activeKey = ENTITIES[0].key;
let charts = {};        // instâncias Chart.js ativas, para destruir ao re-renderizar

const $app = document.getElementById('app');
const $tabs = document.getElementById('tabs');
const $strip = document.getElementById('scoreboard-strip');
const $report = document.getElementById('import-report');

function entityByKey(key) {
  return ENTITIES.find((e) => e.key === key);
}

// ------------------------------------------------------------
// Cliente HTTP para a API PHP
// ------------------------------------------------------------
async function apiCall(pathAndQuery, options = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  const res = await fetch(`${API}/${pathAndQuery}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) {
    showAuthScreen('Sua sessão expirou. Entre novamente.');
    throw new Error(data.erro || 'Não autenticado.');
  }
  if (!res.ok) throw new Error(data.erro || 'Erro desconhecido.');
  return data;
}

const crud = {
  list: (key) => apiCall(`crud.php?entity=${key}`),
  create: (key, payload) => apiCall(`crud.php?entity=${key}`, { method: 'POST', body: JSON.stringify(payload) }),
  update: (key, id, payload) => apiCall(`crud.php?entity=${key}&id=${id}`, { method: 'PUT', body: JSON.stringify(payload) }),
  remove: (key, id) => apiCall(`crud.php?entity=${key}&id=${id}`, { method: 'DELETE' }),
  import: (key, rows) => apiCall(`import.php?entity=${key}`, { method: 'POST', body: JSON.stringify({ rows }) }),
};

// ------------------------------------------------------------
// Autenticação (login / cadastro / logout)
// ------------------------------------------------------------
const $authScreen = document.getElementById('auth-screen');
const $appShell = document.getElementById('app-shell');
const $authError = document.getElementById('auth-error');
const $formLogin = document.getElementById('form-login');
const $formRegistro = document.getElementById('form-registro');

document.querySelectorAll('.auth-toggle-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.auth-toggle-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const isLogin = btn.dataset.mode === 'login';
    $formLogin.classList.toggle('hidden', !isLogin);
    $formRegistro.classList.toggle('hidden', isLogin);
    $authError.classList.add('hidden');
  });
});

function showAuthScreen(message) {
  localStorage.removeItem(TOKEN_KEY);
  currentUser = null;
  $appShell.classList.add('hidden');
  $authScreen.classList.remove('hidden');
  if (message) {
    $authError.textContent = message;
    $authError.classList.remove('hidden');
  } else {
    $authError.classList.add('hidden');
  }
}

async function showAppShell(usuario) {
  currentUser = usuario;
  $authScreen.classList.add('hidden');
  $appShell.classList.remove('hidden');
  document.getElementById('userbar-nome').textContent = usuario.nome;
  await refreshAll();
  renderTabs();
  renderActiveTab();
}

$formLogin.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  $authError.classList.add('hidden');
  const email = $formLogin.elements.email.value;
  const senha = $formLogin.elements.senha.value;
  try {
    const res = await fetch(`${API}/auth.php?action=login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, senha }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || 'Não foi possível entrar.');
    localStorage.setItem(TOKEN_KEY, data.token);
    $formLogin.reset();
    await showAppShell(data.usuario);
  } catch (err) {
    $authError.textContent = err.message;
    $authError.classList.remove('hidden');
  }
});

$formRegistro.addEventListener('submit', async (ev) => {
  ev.preventDefault();
  $authError.classList.add('hidden');
  const payload = {
    nome: $formRegistro.elements.nome.value,
    email: $formRegistro.elements.email.value,
    senha: $formRegistro.elements.senha.value,
  };
  try {
    const res = await fetch(`${API}/auth.php?action=registro`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || 'Não foi possível criar a conta.');
    localStorage.setItem(TOKEN_KEY, data.token);
    $formRegistro.reset();
    await showAppShell(data.usuario);
  } catch (err) {
    $authError.textContent = err.message;
    $authError.classList.remove('hidden');
  }
});

document.getElementById('btn-logout').addEventListener('click', async () => {
  try {
    await fetch(`${API}/auth.php?action=logout`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${localStorage.getItem(TOKEN_KEY)}` },
    });
  } catch (_) { /* ignora falha de rede no logout */ }
  showAuthScreen();
});

async function refreshEntity(key) {
  cache[key] = await crud.list(key);
}

async function refreshAll() {
  await Promise.all(ENTITIES.map((e) => refreshEntity(e.key)));
  renderScoreboard();
}

// ------------------------------------------------------------
// Scoreboard (contador ao vivo por cadastro)
// ------------------------------------------------------------
function renderScoreboard() {
  $strip.innerHTML = ENTITIES.map((e) => `
    <div class="score-cell">
      <span class="score-digits">${String(cache[e.key]?.length ?? 0).padStart(2, '0')}</span>
      <span class="score-label">${e.label}</span>
    </div>
  `).join('<span class="score-div"></span>');
}

// ------------------------------------------------------------
// Abas
// ------------------------------------------------------------
function renderTabs() {
  const todas = [...ENTITIES, ...VIEWS_EXTRA];
  $tabs.innerHTML = todas.map((e) => `
    <button class="tab ${e.key === activeKey ? 'active' : ''}" data-key="${e.key}">${e.label}</button>
  `).join('');
  $tabs.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      activeKey = btn.dataset.key;
      editingRecord = null;
      renderTabs();
      renderActiveTab();
    });
  });
}

function renderActiveTab() {
  if (activeKey === 'dashboard') return renderDashboard();
  if (activeKey === 'ranking') return renderRanking();
  return renderSection(activeKey);
}

// ------------------------------------------------------------
// Formatação de células
// ------------------------------------------------------------
function fkLabelFor(fk, fkLabelField, id) {
  const list = cache[fk] || [];
  const row = list.find((r) => r[entityByKey(fk).pk] === Number(id));
  return row ? `${row[fkLabelField]} (#${id})` : `#${id}`;
}

function formatCell(col, row) {
  if (col.custom) return col.custom(row);
  const value = row[col.key];
  if (value === undefined || value === null || value === '') return '—';
  if (col.format === 'fk') return fkLabelFor(col.fk, col.fkLabel, value);
  if (col.format === 'datetime') {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleString('pt-BR');
  }
  return value;
}

// ------------------------------------------------------------
// Formulário (cadastro e edição)
// ------------------------------------------------------------
function buildFieldControl(field, editando) {
  const wrap = document.createElement('label');
  wrap.className = 'field';
  const obrigatorioVisivel = field.required && !(editando && field.editHint);
  wrap.innerHTML = `<span>${field.label}${obrigatorioVisivel ? ' *' : ''}${editando && field.editHint ? ` (${field.editHint})` : ''}</span>`;

  let control;
  if (field.type === 'select') {
    control = document.createElement('select');
    control.innerHTML = `<option value="">Selecione…</option>` +
      field.options.map((o) => `<option value="${o}">${o}</option>`).join('');
  } else if (field.type === 'fk') {
    control = document.createElement('select');
    const list = cache[field.fk] || [];
    control.innerHTML = `<option value="">${field.required ? 'Selecione…' : 'Nenhum'}</option>` +
      list.map((r) => `<option value="${r[entityByKey(field.fk).pk]}">${r[field.fkLabel]} (#${r[entityByKey(field.fk).pk]})</option>`).join('');
  } else {
    control = document.createElement('input');
    control.type = field.type;
    if (field.placeholder) control.placeholder = field.placeholder;
    if (field.min !== undefined) control.min = field.min;
  }
  control.name = field.name;
  // Em edição, o campo de senha não é obrigatório (deixar em branco mantém a atual).
  if (field.required && !(editando && field.editHint)) control.required = true;
  wrap.appendChild(control);
  return wrap;
}

function preencherFormulario(form, entity, record) {
  entity.fields.forEach((f) => {
    if (f.name === 'senha') return; // nunca pré-preenche senha
    const el = form.elements[f.name];
    if (!el) return;
    let valor = record[f.name];
    if (f.type === 'datetime-local' && valor) {
      valor = String(valor).slice(0, 16).replace(' ', 'T');
    }
    el.value = valor ?? '';
  });
}

function renderSection(key) {
  const entity = entityByKey(key);
  const tpl = document.getElementById('tpl-section');
  const node = tpl.content.cloneNode(true);

  const editando = editingRecord && editingRecord.key === key;

  node.querySelector('h2').textContent = entity.label;
  node.querySelector('.panel-desc').textContent = entity.desc;

  const form = node.querySelector('.record-form');
  entity.fields.forEach((f) => form.appendChild(buildFieldControl(f, editando)));

  const submit = document.createElement('button');
  submit.type = 'submit';
  submit.className = 'btn btn-gold field-submit';
  submit.textContent = editando ? `Salvar alterações` : `Cadastrar ${entity.label.toLowerCase()}`;
  form.appendChild(submit);

  if (editando) {
    const cancelar = document.createElement('button');
    cancelar.type = 'button';
    cancelar.className = 'btn btn-ghost';
    cancelar.textContent = 'Cancelar edição';
    cancelar.addEventListener('click', () => {
      editingRecord = null;
      renderSection(key);
    });
    form.appendChild(cancelar);

    const registroAtual = (cache[key] || []).find((r) => r[entity.pk] === editingRecord.id);
    if (registroAtual) preencherFormulario(form, entity, registroAtual);
  }

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const payload = {};
    entity.fields.forEach((f) => {
      const valor = form.elements[f.name].value;
      if (editando && f.name === 'senha' && !valor) return; // não altera a senha
      payload[f.name] = valor;
    });
    try {
      if (editando) {
        await crud.update(key, editingRecord.id, payload);
        editingRecord = null;
      } else {
        await crud.create(key, payload);
      }
      await refreshAll();
      renderSection(key);
    } catch (err) {
      alert(err.message);
    }
  });

  const thead = node.querySelector('thead');
  thead.innerHTML = '<tr>' + entity.columns.map((c) => `<th>${c.label}</th>`).join('') + '<th></th></tr>';

  const tbody = node.querySelector('tbody');
  const rows = cache[key] || [];
  const emptyState = node.querySelector('.empty-state');
  emptyState.classList.toggle('hidden', rows.length > 0);

  rows.slice().reverse().forEach((row) => {
    const tr = document.createElement('tr');
    tr.innerHTML = entity.columns.map((c) => `<td class="${c.mono ? 'mono' : ''}">${formatCell(c, row)}</td>`).join('');

    const tdActions = document.createElement('td');
    tdActions.className = 'row-actions';

    const edit = document.createElement('button');
    edit.className = 'btn-icon edit';
    edit.title = 'Editar';
    edit.textContent = '✎';
    edit.addEventListener('click', () => {
      editingRecord = { key, id: row[entity.pk] };
      renderSection(key);
    });

    const del = document.createElement('button');
    del.className = 'btn-icon';
    del.title = 'Remover';
    del.textContent = '✕';
    del.addEventListener('click', async () => {
      if (!confirm('Remover este registro?')) return;
      try {
        await crud.remove(key, row[entity.pk]);
        await refreshAll();
        renderSection(key);
      } catch (err) {
        alert(err.message);
      }
    });

    tdActions.appendChild(edit);
    tdActions.appendChild(del);
    tr.appendChild(tdActions);
    tbody.appendChild(tr);
  });

  $app.innerHTML = '';
  $app.appendChild(node);
}

// ------------------------------------------------------------
// Dashboard
// ------------------------------------------------------------
function destruirGraficos() {
  Object.values(charts).forEach((c) => c && c.destroy());
  charts = {};
}

async function renderDashboard() {
  const tpl = document.getElementById('tpl-dashboard');
  const node = tpl.content.cloneNode(true);
  $app.innerHTML = '';
  $app.appendChild(node);

  let dados;
  try {
    dados = await apiCall('dashboard.php');
  } catch (err) {
    $app.innerHTML = `<section class="panel"><p class="dash-empty">Não foi possível carregar o dashboard: ${err.message}</p></section>`;
    return;
  }

  const cartoes = [
    { label: 'Jogadores', value: dados.totais.jogadores },
    { label: 'Clubes', value: dados.totais.clubes },
    { label: 'Temporadas', value: dados.totais.temporadas },
    { label: 'Partidas', value: dados.totais.partidas },
    { label: 'Total de gols', value: dados.totais.gols },
    { label: 'Total de assistências', value: dados.totais.assistencias },
    { label: 'Cartões amarelos', value: dados.totais.cartoes_amarelos },
    { label: 'Cartões vermelhos', value: dados.totais.cartoes_vermelhos },
  ];

  document.getElementById('dash-grid').innerHTML = cartoes.map((c) => `
    <div class="dash-card">
      <span class="dash-value">${c.value}</span>
      <span class="dash-label">${c.label}</span>
    </div>
  `).join('');

  destruirGraficos();

  desenharBarras('chart-artilheiros', dados.artilheiros, 'nome', 'total', '#e8b93b');
  desenharBarras('chart-garcons', dados.garcons, 'nome', 'total', '#7fd99a');
  desenharBarras('chart-temporadas', dados.partidas_por_temporada, 'nome', 'total', '#5fb0e8');

  const m = dados.medias || {};
  const num = (v) => Number(v || 0).toFixed(1);
  document.getElementById('dash-medias').innerHTML = `
    <span>Gols por jogador: <strong>${num(m.media_gols)}</strong></span>
    <span>Assistências por jogador: <strong>${num(m.media_assistencias)}</strong></span>
    <span>Jogos por jogador: <strong>${num(m.media_jogos)}</strong></span>
    <span>Cartões amarelos por jogador: <strong>${num(m.media_cartoes_amarelos)}</strong></span>
    <span>Cartões vermelhos por jogador: <strong>${num(m.media_cartoes_vermelhos)}</strong></span>
  `;
}

function desenharBarras(canvasId, linhas, campoLabel, campoValor, cor) {
  const canvas = document.getElementById(canvasId);
  const box = canvas.closest('.dash-chart-box');
  if (!linhas || linhas.length === 0) {
    canvas.remove();
    const p = document.createElement('p');
    p.className = 'dash-empty';
    p.textContent = 'Sem dados suficientes ainda.';
    box.appendChild(p);
    return;
  }
  charts[canvasId] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: linhas.map((l) => l[campoLabel]),
      datasets: [{ data: linhas.map((l) => Number(l[campoValor])), backgroundColor: cor, borderRadius: 4 }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: '#9fb8a8' }, grid: { display: false } },
        y: { ticks: { color: '#9fb8a8', precision: 0 }, grid: { color: 'rgba(238,243,234,0.08)' } },
      },
    },
  });
}

// ------------------------------------------------------------
// Ranking
// ------------------------------------------------------------
async function renderRanking() {
  const tpl = document.getElementById('tpl-ranking');
  const node = tpl.content.cloneNode(true);
  $app.innerHTML = '';
  $app.appendChild(node);

  const $criterio = document.getElementById('rank-criterio');
  const $temporada = document.getElementById('rank-temporada');
  const $clube = document.getElementById('rank-clube');
  const $posicao = document.getElementById('rank-posicao');

  (cache.temporadas || []).forEach((t) => {
    $temporada.innerHTML += `<option value="${t.id_temporada}">${t.nome}</option>`;
  });
  (cache.clubes || []).forEach((c) => {
    $clube.innerHTML += `<option value="${c.id_clube}">${c.nome}</option>`;
  });

  async function carregar() {
    const params = new URLSearchParams({
      criterio: $criterio.value,
      id_temporada: $temporada.value,
      id_clube: $clube.value,
      posicao: $posicao.value,
    });
    let dados;
    try {
      dados = await apiCall(`ranking.php?${params.toString()}`);
    } catch (err) {
      alert(err.message);
      return;
    }
    const $tbody = document.getElementById('rank-tbody');
    const $empty = document.getElementById('rank-empty');
    $empty.classList.toggle('hidden', dados.jogadores.length > 0);
    $tbody.innerHTML = dados.jogadores.map((j, i) => `
      <tr>
        <td class="ranking-pos">${i + 1}º</td>
        <td>${j.nome}</td>
        <td>${j.clube ?? '—'}</td>
        <td>${j.posicao ?? '—'}</td>
        <td class="mono">${j.jogos}</td>
        <td class="mono">${j.gols}</td>
        <td class="mono">${j.assistencias}</td>
        <td class="mono">${j.cartoes_amarelos}</td>
        <td class="mono">${j.cartoes_vermelhos}</td>
      </tr>
    `).join('');
  }

  [$criterio, $temporada, $clube, $posicao].forEach((el) => el.addEventListener('change', carregar));
  await carregar();
}

// ------------------------------------------------------------
// Excel: baixar modelo
// ------------------------------------------------------------
document.getElementById('btn-template').addEventListener('click', () => {
  const link = document.createElement('a');

  link.href = 'modelo_brmw.xlsx';
  link.download = 'modelo_brmw.xlsx';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
});
// ------------------------------------------------------------
// Excel: importar planilha
// ------------------------------------------------------------
document.getElementById('file-import').addEventListener('change', async (ev) => {
  const file = ev.target.files[0];
  if (!file) return;

  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });

  const summary = [];

  for (const entity of ENTITIES) {
    const sheetName = workbook.SheetNames.find(
      (name) => name.trim().toLowerCase() === entity.key.toLowerCase()
    );
    if (!sheetName) continue;

    const sheet = workbook.Sheets[sheetName];
    const rawRows = XLSX.utils.sheet_to_json(sheet, { defval: '' });
    const rows = rawRows
      .map((r) => {
        const normalized = {};
        Object.entries(r).forEach(([k, v]) => { normalized[k.trim().toLowerCase()] = v; });
        return normalized;
      })
      .filter((r) => Object.values(r).some((v) => String(v).trim() !== ''));

    if (rows.length === 0) continue;

    try {
      const result = await crud.import(entity.key, rows);
      summary.push({ entity, ...result });
      await refreshEntity(entity.key); // dados novos ficam disponíveis para as próximas abas (FKs)
    } catch (err) {
      summary.push({ entity, inserted: [], errors: [{ linha: '-', erro: err.message }] });
    }
  }

  await refreshAll();
  renderActiveTab();
  renderImportReport(summary);
  ev.target.value = '';
});

function renderImportReport(summary) {
  if (summary.length === 0) {
    $report.classList.remove('hidden');
    $report.innerHTML = `<p>Nenhuma aba da planilha correspondeu a um cadastro conhecido (USUARIOS, CLUBES, TEMPORADAS, JOGADORES, ESTATISTICAS, PARTIDAS).</p>`;
    return;
  }
  $report.classList.remove('hidden');
  $report.innerHTML = `
    <div class="import-report-head">
      <strong>Importação concluída</strong>
      <button id="close-report" class="btn-icon">✕</button>
    </div>
    ${summary.map((s) => `
      <div class="import-line">
        <span class="import-entity">${s.entity.label}</span>
        <span class="import-ok">${s.inserted.length} importado(s)</span>
        ${s.errors.length ? `<span class="import-err">${s.errors.length} erro(s)</span>` : ''}
        ${s.errors.length ? `<ul class="import-errlist">${s.errors.map((e) => `<li>Linha ${e.linha}: ${e.erro}</li>`).join('')}</ul>` : ''}
      </div>
    `).join('')}
  `;
  document.getElementById('close-report').addEventListener('click', () => $report.classList.add('hidden'));
}

// ------------------------------------------------------------
// Boot
// ------------------------------------------------------------
(async function init() {
  const token = localStorage.getItem(TOKEN_KEY);
  if (!token) {
    showAuthScreen();
    return;
  }
  try {
    const res = await fetch(`${API}/auth.php?action=me`, { headers: { Authorization: `Bearer ${token}` } });
    const data = await res.json();
    if (!res.ok) throw new Error();
    await showAppShell(data.usuario);
  } catch (_) {
    showAuthScreen();
  }
})();
