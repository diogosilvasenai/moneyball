<?php
// ============================================================
// helpers.php - Funções auxiliares usadas por todos os endpoints
// ============================================================

require_once __DIR__ . '/config.php';

function jsonResponse(int $status, $data): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Lê e decodifica o corpo JSON da requisição (POST/PUT).
function readJsonBody(): array
{
    $raw = file_get_contents('php://input');
    if (!$raw) {
        return [];
    }
    $data = json_decode($raw, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        jsonResponse(400, ['erro' => 'JSON inválido no corpo da requisição.']);
    }
    return is_array($data) ? $data : [];
}

// Extrai o token do cabeçalho "Authorization: Bearer <token>".
// Alguns servidores Apache não repassam o header Authorization por
// padrão; por isso conferimos também as variantes mais comuns.
function getBearerToken(): ?string
{
    $header = $_SERVER['HTTP_AUTHORIZATION']
        ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
        ?? '';

    if (!$header && function_exists('apache_request_headers')) {
        $todos = apache_request_headers();
        $header = $todos['Authorization'] ?? $todos['authorization'] ?? '';
    }

    if (preg_match('/Bearer\s+(\S+)/i', $header, $m)) {
        return $m[1];
    }
    return null;
}

// Retorna os dados do usuário logado (sem senha_hash) ou null.
function usuarioAutenticado(): ?array
{
    $token = getBearerToken();
    if (!$token) {
        return null;
    }
    $pdo = getConexao();
    $stmt = $pdo->prepare(
        'SELECT u.id_usuario, u.nome, u.email, u.criado_em
         FROM SESSOES s
         JOIN USUARIOS u ON u.id_usuario = s.id_usuario
         WHERE s.token = ?'
    );
    $stmt->execute([$token]);
    $usuario = $stmt->fetch();
    return $usuario ?: null;
}

// Exige login válido; encerra a requisição com 401 caso contrário.
function exigirAutenticacao(): array
{
    $usuario = usuarioAutenticado();
    if (!$usuario) {
        jsonResponse(401, ['erro' => 'Não autenticado. Faça login para continuar.']);
    }
    return $usuario;
}
