<?php
// ============================================================
// auth.php - Cadastro de conta, login, logout e sessão atual.
// Endpoints (query string ?action=):
//   POST /api/auth.php?action=registro  { nome, email, senha }
//   POST /api/auth.php?action=login     { email, senha }
//   POST /api/auth.php?action=logout
//   GET  /api/auth.php?action=me
//
// Todas as senhas são conferidas/gravadas com password_hash()/
// password_verify() do PHP (nunca em texto puro). O login cria um
// token em SESSOES, usado depois como "Authorization: Bearer <token>".
// ============================================================

require_once __DIR__ . '/helpers.php';

$acao = $_GET['action'] ?? '';
$pdo = getConexao();
$metodo = $_SERVER['REQUEST_METHOD'];

function sanitizarUsuario(array $u): array
{
    unset($u['senha_hash']);
    return $u;
}

function criarSessao(PDO $pdo, int $idUsuario): string
{
    $token = bin2hex(random_bytes(32));
    $stmt = $pdo->prepare('INSERT INTO SESSOES (token, id_usuario, criado_em) VALUES (?, ?, NOW())');
    $stmt->execute([$token, $idUsuario]);
    return $token;
}

try {
    // ------------------------------------------------------------
    // Criar conta
    // ------------------------------------------------------------
    if ($metodo === 'POST' && $acao === 'registro') {
        $corpo = readJsonBody();
        $nome  = trim((string) ($corpo['nome'] ?? ''));
        $email = trim((string) ($corpo['email'] ?? ''));
        $senha = (string) ($corpo['senha'] ?? '');

        if ($nome === '' || $email === '') {
            jsonResponse(400, ['erro' => 'Nome e e-mail são obrigatórios.']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            jsonResponse(400, ['erro' => 'Informe um e-mail válido.']);
        }
        if (strlen($senha) < 6) {
            jsonResponse(400, ['erro' => 'A senha deve ter pelo menos 6 caracteres.']);
        }

        $stmt = $pdo->prepare('SELECT id_usuario FROM USUARIOS WHERE email = ?');
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            jsonResponse(400, ['erro' => 'Já existe uma conta cadastrada com este e-mail.']);
        }

        $hash = password_hash($senha, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('INSERT INTO USUARIOS (nome, email, senha_hash) VALUES (?, ?, ?)');
        $stmt->execute([$nome, $email, $hash]);
        $idUsuario = (int) $pdo->lastInsertId();

        $token = criarSessao($pdo, $idUsuario);

        $stmt = $pdo->prepare('SELECT * FROM USUARIOS WHERE id_usuario = ?');
        $stmt->execute([$idUsuario]);
        $usuario = sanitizarUsuario($stmt->fetch());

        jsonResponse(201, ['token' => $token, 'usuario' => $usuario]);
    }

    // ------------------------------------------------------------
    // Login
    // ------------------------------------------------------------
    if ($metodo === 'POST' && $acao === 'login') {
        $corpo = readJsonBody();
        $email = trim((string) ($corpo['email'] ?? ''));
        $senha = (string) ($corpo['senha'] ?? '');

        if ($email === '' || $senha === '') {
            jsonResponse(400, ['erro' => 'Informe e-mail e senha.']);
        }

        $stmt = $pdo->prepare('SELECT * FROM USUARIOS WHERE email = ?');
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if (!$usuario || !password_verify($senha, $usuario['senha_hash'])) {
            jsonResponse(401, ['erro' => 'E-mail ou senha inválidos.']);
        }

        $token = criarSessao($pdo, (int) $usuario['id_usuario']);
        jsonResponse(200, ['token' => $token, 'usuario' => sanitizarUsuario($usuario)]);
    }

    // ------------------------------------------------------------
    // Logout
    // ------------------------------------------------------------
    if ($metodo === 'POST' && $acao === 'logout') {
        $token = getBearerToken();
        if ($token) {
            $stmt = $pdo->prepare('DELETE FROM SESSOES WHERE token = ?');
            $stmt->execute([$token]);
        }
        jsonResponse(200, ['ok' => true]);
    }

    // ------------------------------------------------------------
    // Sessão atual (usada no carregamento da página para manter o login)
    // ------------------------------------------------------------
    if ($metodo === 'GET' && $acao === 'me') {
        $usuario = usuarioAutenticado();
        if (!$usuario) {
            jsonResponse(401, ['erro' => 'Sessão inválida ou expirada.']);
        }
        jsonResponse(200, ['usuario' => $usuario]);
    }

    jsonResponse(404, ['erro' => 'Rota de autenticação não encontrada.']);
} catch (PDOException $e) {
    jsonResponse(400, ['erro' => 'Erro de banco de dados: ' . $e->getMessage()]);
}
