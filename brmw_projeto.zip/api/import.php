<?php
// ============================================================
// import.php - Importação em lote (usada pela importação de
// planilha Excel: o navegador lê o .xlsx com SheetJS e envia as
// linhas já como JSON, nada de binário trafega pela rede).
//
// POST /api/import.php?entity=jogadores   body: { "rows": [ {...}, ... ] }
//
// Cada linha é validada individualmente; uma linha com erro não
// impede a importação das demais (o erro é reportado por linha).
// ============================================================

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/validate.php';

$entidade = $_GET['entity'] ?? '';
$schemas = schemaEntidades();

if (!isset($schemas[$entidade])) {
    jsonResponse(404, ['erro' => "Cadastro desconhecido: $entidade"]);
}

exigirAutenticacao();

$pdo = getConexao();
$schema = $schemas[$entidade];
$tabela = $schema['tabela'];
$pk = $schema['pk'];

$corpo = readJsonBody();
$linhas = is_array($corpo['rows'] ?? null) ? $corpo['rows'] : [];

$inseridos = [];
$erros = [];

foreach ($linhas as $i => $linha) {
    if (!is_array($linha)) {
        continue;
    }
    try {
        $linha = comSenhaHash($entidade, $linha);
        $registro = montarRegistro($pdo, $entidade, $linha);

        $colunas = array_keys($registro);
        $marcadores = array_fill(0, count($colunas), '?');
        $sql = "INSERT INTO $tabela (" . implode(',', $colunas) . ') VALUES (' . implode(',', $marcadores) . ')';
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($registro));

        $novoId = $pdo->lastInsertId();
        $stmt2 = $pdo->prepare("SELECT * FROM $tabela WHERE $pk = ?");
        $stmt2->execute([$novoId]);
        $inseridos[] = removerCamposOcultos($entidade, $stmt2->fetch());
    } catch (ValidacaoException $e) {
        $erros[] = ['linha' => $i + 2, 'erro' => $e->getMessage()]; // +2 = cabeçalho + índice 1-based
    } catch (PDOException $e) {
        $mensagem = $e->getCode() === '23000'
            ? 'Violação de restrição do banco (chave estrangeira ou valor duplicado).'
            : ('Erro de banco de dados: ' . $e->getMessage());
        $erros[] = ['linha' => $i + 2, 'erro' => $mensagem];
    }
}

jsonResponse(200, ['inserted' => $inseridos, 'errors' => $erros]);
