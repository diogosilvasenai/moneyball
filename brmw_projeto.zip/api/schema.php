<?php
// ============================================================
// schema.php - Espelha as tabelas de criar_banco_brmw.sql.
// Usado por crud.php, import.php, auth.php etc. para validar e
// montar as consultas de forma genérica, sem repetir SQL em
// cada endpoint.
// ============================================================

const ENTITY_ORDER = ['usuarios', 'clubes', 'temporadas', 'jogadores', 'estatisticas', 'partidas'];

function schemaEntidades(): array
{
    return [
        'usuarios' => [
            'tabela' => 'USUARIOS',
            'pk'     => 'id_usuario',
            'label'  => 'Usuários',
            'campos' => [
                'nome'       => ['tipo' => 'string', 'obrigatorio' => true],
                'email'      => ['tipo' => 'string', 'obrigatorio' => true, 'unico' => true],
                'senha_hash' => ['tipo' => 'string', 'obrigatorio' => true, 'oculto' => true],
            ],
        ],
        'clubes' => [
            'tabela' => 'CLUBES',
            'pk'     => 'id_clube',
            'label'  => 'Clubes',
            'campos' => [
                'nome'   => ['tipo' => 'string', 'obrigatorio' => true],
                'cidade' => ['tipo' => 'string', 'obrigatorio' => false],
            ],
        ],
        'temporadas' => [
            'tabela' => 'TEMPORADAS',
            'pk'     => 'id_temporada',
            'label'  => 'Temporadas',
            'campos' => [
                'nome'        => ['tipo' => 'string', 'obrigatorio' => true],
                'data_inicio' => ['tipo' => 'date', 'obrigatorio' => false],
                'data_fim'    => ['tipo' => 'date', 'obrigatorio' => false],
                'status'      => ['tipo' => 'string', 'obrigatorio' => false],
            ],
        ],
        'jogadores' => [
            'tabela' => 'JOGADORES',
            'pk'     => 'id_jogador',
            'label'  => 'Jogadores',
            'campos' => [
                'id_usuario'      => ['tipo' => 'int', 'obrigatorio' => true, 'fk' => 'usuarios'],
                'id_clube'        => ['tipo' => 'int', 'obrigatorio' => false, 'fk' => 'clubes'],
                'nome'            => ['tipo' => 'string', 'obrigatorio' => true],
                'data_nascimento' => ['tipo' => 'date', 'obrigatorio' => false],
                'posicao'         => ['tipo' => 'string', 'obrigatorio' => false],
            ],
        ],
        'estatisticas' => [
            'tabela' => 'ESTATISTICAS',
            'pk'     => 'id_estatistica',
            'label'  => 'Estatísticas',
            'campos' => [
                'id_jogador'        => ['tipo' => 'int', 'obrigatorio' => true, 'fk' => 'jogadores'],
                'id_temporada'      => ['tipo' => 'int', 'obrigatorio' => false, 'fk' => 'temporadas'],
                'jogos'             => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'gols'              => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'assistencias'      => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'cartoes_amarelos'  => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'cartoes_vermelhos' => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
            ],
        ],
        'partidas' => [
            'tabela' => 'PARTIDAS',
            'pk'     => 'id_partida',
            'label'  => 'Partidas',
            'campos' => [
                'id_temporada'      => ['tipo' => 'int', 'obrigatorio' => true, 'fk' => 'temporadas'],
                'id_time_mandante'  => ['tipo' => 'int', 'obrigatorio' => true, 'fk' => 'clubes'],
                'id_time_visitante' => ['tipo' => 'int', 'obrigatorio' => true, 'fk' => 'clubes'],
                'data_partida'      => ['tipo' => 'string', 'obrigatorio' => false],
                'campeonato'        => ['tipo' => 'string', 'obrigatorio' => false],
                'gols_mandante'     => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'gols_visitante'    => ['tipo' => 'int', 'obrigatorio' => false, 'padrao' => 0],
                'status'            => ['tipo' => 'string', 'obrigatorio' => false],
            ],
        ],
    ];
}
