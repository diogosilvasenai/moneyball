<?php
// ============================================================
// config.php - Conexão com o banco MySQL
// Ajuste as constantes abaixo conforme o seu ambiente
// (XAMPP/WAMP local, phpMyAdmin, hospedagem, etc.)
// ============================================================

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'brmw');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

function getConexao(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'erro' => 'Não foi possível conectar ao banco MySQL "brmw". '
                    . 'Verifique host/usuário/senha em api/config.php e se o banco foi '
                    . 'importado a partir de criar_banco_brmw.sql. Detalhe técnico: ' . $e->getMessage(),
            ]);
            exit;
        }
    }
    return $pdo;
}
