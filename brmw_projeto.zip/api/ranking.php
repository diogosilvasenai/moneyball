<?php
// ============================================================
// ranking.php - Ranking de jogadores a partir de ESTATISTICAS,
// com critério de ordenação e filtros opcionais.
//
// GET /api/ranking.php
//     ?criterio=gols|assistencias|jogos|cartoes_amarelos|cartoes_vermelhos
//     &id_temporada=..   (opcional)
//     &id_clube=..       (opcional)
//     &posicao=..        (opcional)
// ============================================================

require_once __DIR__ . '/helpers.php';

exigirAutenticacao();
$pdo = getConexao();

$criteriosValidos = ['gols', 'assistencias', 'jogos', 'cartoes_amarelos', 'cartoes_vermelhos'];
$criterio = in_array($_GET['criterio'] ?? '', $criteriosValidos, true) ? $_GET['criterio'] : 'gols';

$where = [];
$params = [];

if (!empty($_GET['id_temporada'])) {
    $where[] = 'e.id_temporada = ?';
    $params[] = $_GET['id_temporada'];
}
if (!empty($_GET['id_clube'])) {
    $where[] = 'j.id_clube = ?';
    $params[] = $_GET['id_clube'];
}
if (!empty($_GET['posicao'])) {
    $where[] = 'j.posicao = ?';
    $params[] = $_GET['posicao'];
}

$sqlWhere = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

try {
    $sql = "SELECT j.id_jogador, j.nome, j.posicao, c.nome AS clube,
                   SUM(e.jogos) AS jogos,
                   SUM(e.gols) AS gols,
                   SUM(e.assistencias) AS assistencias,
                   SUM(e.cartoes_amarelos) AS cartoes_amarelos,
                   SUM(e.cartoes_vermelhos) AS cartoes_vermelhos
            FROM ESTATISTICAS e
            JOIN JOGADORES j ON j.id_jogador = e.id_jogador
            LEFT JOIN CLUBES c ON c.id_clube = j.id_clube
            $sqlWhere
            GROUP BY j.id_jogador, j.nome, j.posicao, c.nome
            ORDER BY $criterio DESC, j.nome ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $jogadores = $stmt->fetchAll();

    jsonResponse(200, ['criterio' => $criterio, 'jogadores' => $jogadores]);
} catch (PDOException $e) {
    jsonResponse(400, ['erro' => 'Erro de banco de dados: ' . $e->getMessage()]);
}
