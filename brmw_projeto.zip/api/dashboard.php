<?php
// ============================================================
// dashboard.php - Indicadores agregados a partir dos dados reais
// do banco (nada é inventado; tudo vem de consultas SQL).
// GET /api/dashboard.php
// ============================================================

require_once __DIR__ . '/helpers.php';

exigirAutenticacao();
$pdo = getConexao();

function contarValor(PDO $pdo, string $sql): int
{
    $linha = $pdo->query($sql)->fetch(PDO::FETCH_NUM);
    return $linha ? (int) $linha[0] : 0;
}

try {
    $totais = [
        'jogadores'          => contarValor($pdo, 'SELECT COUNT(*) FROM JOGADORES'),
        'clubes'             => contarValor($pdo, 'SELECT COUNT(*) FROM CLUBES'),
        'temporadas'         => contarValor($pdo, 'SELECT COUNT(*) FROM TEMPORADAS'),
        'partidas'           => contarValor($pdo, 'SELECT COUNT(*) FROM PARTIDAS'),
        'gols'               => contarValor($pdo, 'SELECT COALESCE(SUM(gols),0) FROM ESTATISTICAS'),
        'assistencias'       => contarValor($pdo, 'SELECT COALESCE(SUM(assistencias),0) FROM ESTATISTICAS'),
        'cartoes_amarelos'   => contarValor($pdo, 'SELECT COALESCE(SUM(cartoes_amarelos),0) FROM ESTATISTICAS'),
        'cartoes_vermelhos'  => contarValor($pdo, 'SELECT COALESCE(SUM(cartoes_vermelhos),0) FROM ESTATISTICAS'),
    ];

    $artilheiros = $pdo->query(
        'SELECT j.nome, c.nome AS clube, SUM(e.gols) AS total
         FROM ESTATISTICAS e
         JOIN JOGADORES j ON j.id_jogador = e.id_jogador
         LEFT JOIN CLUBES c ON c.id_clube = j.id_clube
         GROUP BY e.id_jogador, j.nome, c.nome
         HAVING total > 0
         ORDER BY total DESC
         LIMIT 5'
    )->fetchAll();

    $garcons = $pdo->query(
        'SELECT j.nome, c.nome AS clube, SUM(e.assistencias) AS total
         FROM ESTATISTICAS e
         JOIN JOGADORES j ON j.id_jogador = e.id_jogador
         LEFT JOIN CLUBES c ON c.id_clube = j.id_clube
         GROUP BY e.id_jogador, j.nome, c.nome
         HAVING total > 0
         ORDER BY total DESC
         LIMIT 5'
    )->fetchAll();

    $partidasPorTemporada = $pdo->query(
        'SELECT t.nome, COUNT(p.id_partida) AS total
         FROM TEMPORADAS t
         LEFT JOIN PARTIDAS p ON p.id_temporada = t.id_temporada
         GROUP BY t.id_temporada, t.nome
         ORDER BY t.nome'
    )->fetchAll();

    $medias = $pdo->query(
        'SELECT
            COALESCE(AVG(gols),0)              AS media_gols,
            COALESCE(AVG(assistencias),0)      AS media_assistencias,
            COALESCE(AVG(jogos),0)             AS media_jogos,
            COALESCE(AVG(cartoes_amarelos),0)  AS media_cartoes_amarelos,
            COALESCE(AVG(cartoes_vermelhos),0) AS media_cartoes_vermelhos
         FROM ESTATISTICAS'
    )->fetch();

    jsonResponse(200, [
        'totais'                 => $totais,
        'artilheiros'            => $artilheiros,
        'garcons'                => $garcons,
        'partidas_por_temporada' => $partidasPorTemporada,
        'medias'                 => $medias,
    ]);
} catch (PDOException $e) {
    jsonResponse(400, ['erro' => 'Erro de banco de dados: ' . $e->getMessage()]);
}
