<?php
// ============================================================
// validate.php - Validação e montagem de registros a partir do
// schema declarativo, compartilhada por crud.php e import.php.
// ============================================================

require_once __DIR__ . '/schema.php';

class ValidacaoException extends Exception
{
}

function coerceValor($valor, string $tipo)
{
    if ($valor === null || $valor === '') {
        return null;
    }
    if ($tipo === 'int') {
        if (!is_numeric($valor)) {
            throw new ValidacaoException("Valor numérico inválido: \"$valor\"");
        }
        return (int) $valor;
    }
    return trim((string) $valor);
}

// Monta e valida um registro para INSERT ou UPDATE.
// $existente: registro atual (em caso de edição, para manter valores
// não enviados e permitir e-mail igual ao do próprio usuário).
function montarRegistro(PDO $pdo, string $entidade, array $entradas, ?array $existente = null): array
{
    $schema = schemaEntidades()[$entidade];
    $registro = [];

    foreach ($schema['campos'] as $campo => $regras) {
        $bruto = array_key_exists($campo, $entradas) ? $entradas[$campo] : null;
        $valor = coerceValor($bruto, $regras['tipo']);

        if ($valor === null) {
            if ($existente !== null && array_key_exists($campo, $existente) && !array_key_exists($campo, $entradas)) {
                // Edição parcial: campo não enviado mantém o valor atual.
                $valor = $existente[$campo];
            } elseif ($regras['obrigatorio']) {
                throw new ValidacaoException("Campo obrigatório ausente: $campo");
            } elseif (isset($regras['padrao'])) {
                $valor = $regras['padrao'];
            }
        }

        if ($valor !== null && !empty($regras['fk'])) {
            $refSchema = schemaEntidades()[$regras['fk']];
            $stmt = $pdo->prepare("SELECT 1 FROM {$refSchema['tabela']} WHERE {$refSchema['pk']} = ?");
            $stmt->execute([$valor]);
            if (!$stmt->fetch()) {
                throw new ValidacaoException("Chave estrangeira inválida: $campo=$valor não existe em {$regras['fk']}.");
            }
        }

        if ($valor !== null && !empty($regras['unico'])) {
            $stmt = $pdo->prepare("SELECT {$schema['pk']} FROM {$schema['tabela']} WHERE $campo = ?");
            $stmt->execute([$valor]);
            $linha = $stmt->fetch();
            if ($linha && (!$existente || (int) $linha[$schema['pk']] !== (int) $existente[$schema['pk']])) {
                throw new ValidacaoException("Valor duplicado para campo único \"$campo\": $valor");
            }
        }

        $registro[$campo] = $valor;
    }

    if ($entidade === 'partidas') {
        $mandante = $registro['id_time_mandante'];
        $visitante = $registro['id_time_visitante'];
        if ($mandante !== null && $visitante !== null && (int) $mandante === (int) $visitante) {
            throw new ValidacaoException('id_time_mandante e id_time_visitante devem ser diferentes.');
        }
    }

    return $registro;
}

// Converte o campo "senha" (texto puro vindo do formulário/planilha)
// em "senha_hash" antes de persistir. Nunca gravamos senha em texto puro.
function comSenhaHash(string $entidade, array $entradas): array
{
    if ($entidade !== 'usuarios' || empty($entradas['senha'])) {
        return $entradas;
    }
    $entradas['senha_hash'] = password_hash((string) $entradas['senha'], PASSWORD_DEFAULT);
    unset($entradas['senha']);
    return $entradas;
}

// Remove campos marcados como 'oculto' (ex.: senha_hash) antes de responder.
function removerCamposOcultos(string $entidade, array $registro): array
{
    $schema = schemaEntidades()[$entidade];
    foreach ($schema['campos'] as $campo => $regras) {
        if (!empty($regras['oculto'])) {
            unset($registro[$campo]);
        }
    }
    return $registro;
}
