<?php
// ============================================================
// crud.php - Listagem, criação, edição e exclusão genéricas.
// Endpoints (query string):
//   GET    /api/crud.php?entity=jogadores            -> lista tudo
//   GET    /api/crud.php?entity=jogadores&id=5        -> um registro
//   POST   /api/crud.php?entity=jogadores  (corpo JSON) -> cria
//   PUT    /api/crud.php?entity=jogadores&id=5 (JSON)   -> edita
//   DELETE /api/crud.php?entity=jogadores&id=5          -> remove
//
// entity: usuarios | clubes | temporadas | jogadores | estatisticas | partidas
// Todas as rotas exigem login (Authorization: Bearer <token>).
// ============================================================

require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/validate.php';

$entidade = $_GET['entity'] ?? '';
$schemas = schemaEntidades();

if (!isset($schemas[$entidade])) {
    jsonResponse(404, ['erro' => "Cadastro desconhecido: $entidade"]);
}

exigirAutenticacao();

$pdo = getConexao();
$schema = $schemas[$entidade];
$tabela = $schema['tabela'];
$pk = $schema['pk'];
$metodo = $_SERVER['REQUEST_METHOD'];

function buscarRegistro(PDO $pdo, string $tabela, string $pk, $id): ?array
{
    $stmt = $pdo->prepare("SELECT * FROM $tabela WHERE $pk = ?");
    $stmt->execute([$id]);
    $linha = $stmt->fetch();
    return $linha ?: null;
}

try {
    // -------------------- LISTAR --------------------
    if ($metodo === 'GET' && !isset($_GET['id'])) {
        $stmt = $pdo->query("SELECT * FROM $tabela ORDER BY $pk ASC");
        $linhas = array_map(fn($l) => removerCamposOcultos($entidade, $l), $stmt->fetchAll());
        jsonResponse(200, $linhas);
    }

    // -------------------- BUSCAR UM --------------------
    if ($metodo === 'GET' && isset($_GET['id'])) {
        $linha = buscarRegistro($pdo, $tabela, $pk, $_GET['id']);
        if (!$linha) {
            jsonResponse(404, ['erro' => 'Registro não encontrado.']);
        }
        jsonResponse(200, removerCamposOcultos($entidade, $linha));
    }

    // -------------------- CRIAR --------------------
    if ($metodo === 'POST') {
        $corpo = comSenhaHash($entidade, readJsonBody());
        $registro = montarRegistro($pdo, $entidade, $corpo);

        $colunas = array_keys($registro);
        $marcadores = array_fill(0, count($colunas), '?');
        $sql = "INSERT INTO $tabela (" . implode(',', $colunas) . ') VALUES (' . implode(',', $marcadores) . ')';
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_values($registro));

        $novoId = $pdo->lastInsertId();
        $linha = buscarRegistro($pdo, $tabela, $pk, $novoId);
        jsonResponse(201, removerCamposOcultos($entidade, $linha));
    }

    // -------------------- EDITAR --------------------
    if ($metodo === 'PUT') {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            jsonResponse(400, ['erro' => 'Informe o id do registro a editar.']);
        }
        $existente = buscarRegistro($pdo, $tabela, $pk, $id);
        if (!$existente) {
            jsonResponse(404, ['erro' => 'Registro não encontrado.']);
        }

        $corpo = comSenhaHash($entidade, readJsonBody());
        $registro = montarRegistro($pdo, $entidade, $corpo, $existente);

        $sets = implode(',', array_map(fn($c) => "$c = ?", array_keys($registro)));
        $sql = "UPDATE $tabela SET $sets WHERE $pk = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([...array_values($registro), $id]);

        $linha = buscarRegistro($pdo, $tabela, $pk, $id);
        jsonResponse(200, removerCamposOcultos($entidade, $linha));
    }

    // -------------------- EXCLUIR --------------------
    if ($metodo === 'DELETE') {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            jsonResponse(400, ['erro' => 'Informe o id do registro a remover.']);
        }
        $existente = buscarRegistro($pdo, $tabela, $pk, $id);
        if (!$existente) {
            jsonResponse(404, ['erro' => 'Registro não encontrado.']);
        }

        try {
            $stmt = $pdo->prepare("DELETE FROM $tabela WHERE $pk = ?");
            $stmt->execute([$id]);
        } catch (PDOException $e) {
            // Violação de chave estrangeira (equivalente ao ON DELETE RESTRICT).
            if ($e->getCode() === '23000') {
                jsonResponse(409, ['erro' => "Não é possível remover: existem registros vinculados a este(a) {$schema['label']}."]);
            }
            throw $e;
        }

        jsonResponse(200, removerCamposOcultos($entidade, $existente));
    }

    jsonResponse(404, ['erro' => 'Rota não encontrada.']);
} catch (ValidacaoException $e) {
    jsonResponse(400, ['erro' => $e->getMessage()]);
} catch (PDOException $e) {
    jsonResponse(400, ['erro' => 'Erro de banco de dados: ' . $e->getMessage()]);
}
